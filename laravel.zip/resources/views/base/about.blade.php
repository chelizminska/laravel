@extends('base.layout')
@section('content')
    {!! $page['content'] !!}
@endsection