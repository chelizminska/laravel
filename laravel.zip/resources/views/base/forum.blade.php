@extends('base.layout')
@section('content')
    <div class="forum_topics">
        @if(Auth::user() and !$parent_page->is_protected)
            <div class="add_topic">
               <a href="/forum/{{ $parent_page->id }}/newtopic">Создать тему</a>
            </div>
        @endif
        @if(isset($topics))
        @foreach($topics as $key => $topic)
            <div class="topic">
                <a href="/forum/{{$topic->id}}?page_number=1">{{$topic->title}}</a>
                @if($topic->is_sheet)
                    {{ $page_messages[$key][0]->user }}
                    {{ sizeof($page_messages[$key]) }}
                @else
                    {{ $topic->child_amount }}
                @endif
            </div>
        @endforeach
        @endif
    </div>
@endsection