@extends('base.layout')
@section('content')
    {{ $message->content }}
@endsection