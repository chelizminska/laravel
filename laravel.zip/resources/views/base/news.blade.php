@extends('base.layout')
@section('content')
    @foreach ($news as $n)
        <div>
            <a href="/viewNews?id={{ $n->id }}">{{ $n->title }}</a>
        </div>
    @endforeach
@endsection