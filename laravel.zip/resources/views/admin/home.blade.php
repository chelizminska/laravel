@extends('admin.layout')
@section('content')
    <div class="categories">
        <a href="/admin/contents">Управление контентом страниц</a><br>
        <a href="/admin/users">Управление пользователями</a><br>
        <a href="/admin/justify">Просмотр статистики сайта</a><br>
    </div>
@endsection