@extends('admin.layout')
@section('content')
    <div class="categories">
        <a href="/admin/contents/home">Главная</a><br>
        <a href="/admin/contents/forum">Форум</a><br>
        <a href="/admin/contents/fishes">Рыбы беларуси</a><br>
        <a href="/admin/contents/news">Новости</a><br>
        <a href="/admin/contents/about">О клубе</a><br>
        <a href="/admin/contents/contacts">Контакты</a><br>
    </div>
@endsection