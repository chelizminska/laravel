<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
//Public//////////////////
//baseC
Route::get('/', ['as' => 'home', 'uses' => 'Base\BaseController@indexAction']);
Route::get('/fishes', 'Base\BaseController@fishesAction');
Route::get('/fishes/{id}', 'Base\BaseController@fishInfoAction');
Route::get('/news', 'Base\BaseController@newsAction');
Route::get('/viewNews', 'Base\BaseController@viewNewsAction');
Route::get('/about', 'Base\BaseController@aboutAction');
Route::get('/contacts', 'Base\BaseController@contactsAction');
Route::get('/aaa', 'Base\BaseController@aaaAction');
Route::get('/bbb', 'Base\BaseController@bbbAction');
Route::get('/forum/{id?}', 'Base\BaseController@forumAction');
Route::get('/forum/{id?}/newtopic', 'Base\BaseController@getForumAddTopicAction');
Route::post('/forum/{id?}/newtopic', 'Base\BaseController@postForumAddTopicAction');
Route::post('/forum/{id}/add', 'Base\BaseController@forumAddMessageAction');
Route::get('/personal_info', 'Base\BaseController@showPersonalInfoAction');
Route::get('/personal_messages', 'Base\BaseController@showPersonalMessagesAction');
Route::get('/personal_message', 'Base\BaseController@viewPersonalMessageAction');
Route::get('/user', 'Base\BaseController@showUserInfoAction');
Route::get('/personal_info_change', 'Base\BaseController@changePersonalInfoAction');
Route::post('/personal_info_save', 'Base\BaseController@savePersonalInfoAction');
Route::get('/send_message_to_user', 'Base\BaseController@getUserSendMessageAction');
Route::post('/send_message_to_user', 'Base\BaseController@postUserSendMessageAction');

//authC
Route::get('/register', ['as' => 'user-registration', 'uses' => 'Base\AuthController@getRegisterAction']);
Route::post('/register', ['uses' => 'Base\AuthController@postRegisterAction']);
Route::get('/login', ['as' => 'user-login', 'uses' => 'Base\AuthController@getLoginAction']);
Route::post('/login', ['uses' => 'Base\AuthController@postLoginAction']);
Route::get('/logout', 'Base\AuthController@logoutAction');




//Admin////////////////////
//baseC
Route::get('/admin', ['as' => 'admin', 'uses' => 'Admin\BaseController@indexAction']);
Route::get('/admin/contents', 'Admin\BaseController@contentManagementAction');
Route::get('/admin/users', 'Admin\BaseController@usersManagementAction');
Route::get('/admin/users/{id}', 'Admin\BaseController@showUserInfoAction');
Route::post('/admin/users/{id}/giveWarning', 'Admin\BaseController@giveWarningAction');
Route::get('/admin/statistics', 'Admin\BaseController@siteStatisticsAction');

Route::get('/admin/contents/home', 'Admin\BaseController@getHomeEditingAction');
Route::post('/admin/contents/home', 'Admin\BaseController@postHomeEditingAction');

Route::get('/admin/contents/forum/{id?}', 'Admin\BaseController@forumShowAction');
Route::get('/admin/contents/forum/{id}/newtopic', 'Admin\BaseController@getForumNewTopicAction');
Route::post('/admin/contents/forum/{id}/newtopic', 'Admin\BaseController@postForumNewTopicAction');
Route::get('/admin/contents/forum/{id?}/add', 'Admin\BaseController@getForumAddingAction');
Route::post('/admin/contents/forum/{id?}/add', 'Admin\BaseController@postForumAddingAction');
Route::get('/admin/contents/forum/{id}/edit', 'Admin\BaseController@getForumEditingAction');
Route::post('/admin/contents/forum/{id}/edit', 'Admin\BaseController@postForumEditingAction');
Route::get('/admin/contents/forum/{page_id}/delete', 'Admin\BaseController@deleteForumTopicAction');
Route::post('/admin/contents/forum/{page_id}/{message_id}/delete', 'Admin\BaseController@deleteForumTopicMessageAction');

Route::get('/admin/contents/fishes', 'Admin\BaseController@showFishesAction');
Route::get('/admin/contents/fishes/edit/{id}', 'Admin\BaseController@getFishesEditingAction');
Route::post('/admin/contents/fishes/edit/{id}', 'Admin\BaseController@postFishesEditingAction');
Route::get('/admin/contents/fishes/delete', 'Admin\BaseController@deleteFishAction');
Route::get('/admin/contents/fishes/add', 'Admin\BaseController@getFishesAddingAction');
Route::post('/admin/contents/fishes/add', 'Admin\BaseController@postFishesAddingAction');

Route::get('/admin/contents/news', 'Admin\BaseController@newsShowAction');
Route::get('/admin/contents/news/edit', 'Admin\BaseController@getNewsEditAction');
Route::post('/admin/contents/news/edit', 'Admin\BaseController@postNewsEditAction');
Route::post('/admin/contents/news/delete', 'Admin\BaseController@newsDeleteAction');
Route::get('/admin/contents/news/add', 'Admin\BaseController@getNewsAddAction');
Route::post('/admin/contents/news/add', 'Admin\BaseController@postNewsAddAction');

Route::get('/admin/contents/about', 'Admin\BaseController@getAboutEditingAction');
Route::post('/admin/contents/about', 'Admin\BaseController@postAboutEditingAction');

Route::get('/admin/contents/contacts', 'Admin\BaseController@getContactsEditingAction');
Route::post('/admin/contents/contacts', 'Admin\BaseController@postContactsEditingAction');

//authC
Route::get('/admin/register', 'Admin\AuthController@getRegisterAction');
Route::post('/admin/register', 'Admin\AuthController@postRegisterAction');
Route::get('/admin/login', 'Admin\AuthController@getLoginAction');
Route::post('/admin/login', 'Admin\AuthController@postLoginAction');
Route::get('/admin/logout', 'Admin\AuthController@logoutAction');