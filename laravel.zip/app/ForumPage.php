<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ForumPage extends Model
{
    //
}
